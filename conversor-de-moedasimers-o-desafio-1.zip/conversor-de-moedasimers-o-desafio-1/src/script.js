// Objeto com as taxas de câmbio simuladas
const exchangeRates = {
  USD: { BRL: 5.5, ARS: 110, BTC: 0.00003, ETH: 0.0009, EUR: 0.85 },
  BRL: {
    USD: 1 / 5.5,
    ARS: 0.02,
    BTC: 1 / 183283.92,
    ETH: 1 / 10046.58,
    EUR: 0.18
  },
  ARS: {
    USD: 1 / 110,
    BRL: 50,
    BTC: 1 / 3660940.0,
    ETH: 1 / 201835.42,
    EUR: 0.0094
  },
  BTC: {
    USD: 33333.33,
    BRL: 183283.92,
    ARS: 3660940.0,
    ETH: 0.03571429,
    EUR: 30000
  },
  ETH: { USD: 1111.11, BRL: 10046.58, ARS: 201835.42, BTC: 28, EUR: 1111.11 },
  EUR: { USD: 1.18, BRL: 5.56, ARS: 106.38, BTC: 1 / 30000, ETH: 1 / 1111.11 }
};

// Função para realizar a conversão de moeda
function convertCurrency() {
  // Obtenção dos valores dos campos e listas suspensas
  const amount = parseFloat(document.getElementById("amount").value);
  const fromCurrency = document.getElementById("fromCurrency").value;
  const toCurrency = document.getElementById("toCurrency").value;

  // Obtenção da taxa de câmbio específica para a conversão desejada
  let exchangeRate = exchangeRates[fromCurrency][toCurrency];

  // Verificação da existência da taxa de câmbio
  if (isNaN(amount) || isNaN(exchangeRate)) {
    document.getElementById("convertedAmount").value =
      "Por favor, insira um valor válido.";
  } else {
    // Cálculo do valor convertido e exibição no campo correspondente
    const convertedAmount = amount * exchangeRate;
    document.getElementById("convertedAmount").value =
      convertedAmount.toFixed(2) + ` ${toCurrency}`;
  }
}
